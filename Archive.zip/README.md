# Flask-Form-Bootstrap
Code for creating forms in flask, and used bootstrap for styling the webiste. Also retrieved user data and stored them in session variables ,which can be sent to database. Complete explanation on my youtube channel: https://www.youtube.com/watch?v=OFirb6PxH44&amp;t=384s

Run 
pip install -r requirements.txt

Run
flask run